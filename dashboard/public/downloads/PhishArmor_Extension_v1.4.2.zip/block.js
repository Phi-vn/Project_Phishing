// PhishArmor AI - Block Page Logic (Manifest V3 Compliant)

document.addEventListener("DOMContentLoaded", () => {
  try {
    const params = new URLSearchParams(window.location.search);
    const rawUrl = params.get("url");
    const rawTrustScore = params.get("trust_score") || params.get("score");

    if (rawUrl) {
      let displayUrl = rawUrl;
      try {
        const u = new URL(rawUrl);
        displayUrl = u.hostname + (u.pathname !== "/" ? u.pathname : "");
      } catch (e) {
        displayUrl = rawUrl.replace(/^https?:\/\//i, "");
      }

      const blockedUrlEl = document.getElementById("blocked-url");
      if (blockedUrlEl) {
        blockedUrlEl.innerText = displayUrl;
      }
      document.title = "Đã chặn nguy hiểm: " + displayUrl + " - PhishArmor AI";

      // Cập nhật linh hoạt nội dung giải thích XAI theo từng loại URL
      updateDynamicXAI(displayUrl);
    }

    // Hiển thị thống nhất nhãn Trust Score (Điểm tin cậy: Càng thấp càng nguy hiểm)
    let trustScoreNum = 8;
    if (rawTrustScore) {
      const val = parseInt(rawTrustScore, 10);
      if (!isNaN(val)) {
        trustScoreNum = Math.min(100, Math.max(1, val));
      }
    }
    const badgeEl = document.getElementById("risk-badge");
    if (badgeEl) {
      badgeEl.innerText = `Trust Score: ${trustScoreNum}/100`;
    }

    // Xử lý sự kiện click cho các nút hành động (Manifest V3 - Không dùng inline onclick)

    // 1. Nút Quay Lại Trang An Toàn
    const safeBtn = document.getElementById("btn-safe");
    if (safeBtn) {
      safeBtn.addEventListener("click", () => {
        window.location.href = "https://www.google.com";
      });
    }

    // 2. Nút Báo cáo nhầm lẫn (False Positive)
    const reportBtn = document.getElementById("btn-report");
    const toastMsg = document.getElementById("toast-msg");
    if (reportBtn) {
      reportBtn.addEventListener("click", async () => {
        reportBtn.disabled = true;
        reportBtn.style.opacity = "0.7";
        reportBtn.innerText = "Đang gửi báo cáo...";

        try {
          const apiBase = (typeof PHISHARMOR_API_BASE !== "undefined") ? PHISHARMOR_API_BASE : "http://127.0.0.1:8000";
          await fetch(`${apiBase}/api/feedback`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              url: rawUrl || window.location.href,
              report_type: "false_positive",
              reason: "Người dùng báo cáo nhầm lẫn từ màn hình cảnh báo tiện ích PhishArmor",
              email: "analyst@phisharmor.vn",
              confidence_score: 95.0,
              ai_prediction: "Đã kích hoạt Chặn (Nguy cơ Phishing cao)"
            })
          });
        } catch (e) {
          console.warn("[PhishArmor] Gửi feedback:", e);
        }

        reportBtn.innerText = "✓ Đã báo cáo nhầm lẫn";
        if (toastMsg) {
          toastMsg.style.display = "block";
          toastMsg.innerText = "✓ Đã ghi nhận báo cáo! Hệ thống SOC sẽ tiến hành phúc tra an toàn.";
        }
      });
    }

    // 3. Nút Bỏ qua rủi ro và tiếp tục truy cập (Bypass)
    const bypassBtn = document.getElementById("btn-bypass");
    if (bypassBtn) {
      bypassBtn.addEventListener("click", () => {
        if (rawUrl) {
          const disclaimer = 
            "⚠️ XÁC NHẬN VƯỢT RÀO CẢNH BÁO & MIỄN TRỪ TRÁCH NHIỆM:\n\n" +
            "Trang web này đã bị hệ thống PhishArmor AI nhận diện có nguy cơ LỪA ĐẢO NGUY HIỂM.\n\n" +
            "Nếu bạn vẫn quyết định tiếp tục truy cập (Bypass):\n" +
            "1. Thao tác này hoàn toàn nằm ngoài khuyến nghị bảo mật và nghiệp vụ bảo vệ an toàn của hệ thống.\n" +
            "2. Bạn đồng ý tự chịu 100% rủi ro về rò rỉ thông tin cá nhân, tài khoản ngân hàng hoặc thất thoát dữ liệu.\n" +
            "3. Đội ngũ phát triển và hệ thống PhishArmor hoàn toàn KHÔNG CHỊU TRÁCH NHIỆM pháp lý hoặc bồi thường thiệt hại đối với các rủi ro phát sinh.\n\n" +
            "Bạn có chắc chắn muốn bỏ qua cảnh báo và tiếp tục truy cập không?";

          if (confirm(disclaimer)) {
            try {
              chrome.runtime.sendMessage({ action: "bypass_url", url: rawUrl }, () => {
                window.location.href = rawUrl;
              });
            } catch (e) {
              window.location.href = rawUrl;
            }
          }
        }
      });
    }
  } catch (err) {
    console.error("[PhishArmor Block] Error loading parameters:", err);
  }
});

function updateDynamicXAI(targetUrl) {
  const lower = targetUrl.toLowerCase();
  const xaiContentEl = document.getElementById("xai-content");
  if (!xaiContentEl) return;

  // 0. Kịch bản Tấn công ký tự đồng hình (IDN Homograph / Font chữ nhái Punycode xn--, Cyrillic, Greek)
  if (lower.includes("xn--") || /[а-яА-ЯёЁ\u0400-\u04FF\u0370-\u03FF]/.test(lower) || lower.includes("homograph")) {
    xaiContentEl.innerHTML = `
      <div class="xai-item">
        <span>🔤</span>
        <div>
          <strong>Tấn công ký tự đồng hình (IDN Homograph / Font nhái)</strong>
          <span>Kẻ tấn công cố tình dùng chữ cái ngoại ngữ (Cyrillic/Punycode) có hình dáng giống hệt chữ Latinh để đánh lừa mắt thường.</span>
        </div>
      </div>
      <div class="xai-item">
        <span>🛡️</span>
        <div>
          <strong>Mạo danh thương hiệu uy tín</strong>
          <span>Địa chỉ URL hiển thị giống trang web thật nhưng máy chủ thực tế trỏ tới hạ tầng độc hại.</span>
        </div>
      </div>
    `;
    return;
  }

  // 1. Kịch bản Mạng xã hội (Facebook, Zalo, TikTok, Meta...)
  if (lower.includes("facebook") || lower.includes("fb") || lower.includes("zalo") || lower.includes("gift") || lower.includes("free")) {
    xaiContentEl.innerHTML = `
      <div class="xai-item">
        <span>🚨</span>
        <div>
          <strong>Mạo danh Mạng Xã Hội (Facebook Phishing)</strong>
          <span>Chiêu trò tặng quà ảo (Gift/Free) dụ dỗ người dùng đăng nhập tài khoản.</span>
        </div>
      </div>
      <div class="xai-item">
        <span>🔑</span>
        <div>
          <strong>Đánh cắp Cookie & Tài khoản cá nhân</strong>
          <span>Phát hiện mã nguồn thu thập trái phép mật khẩu đăng nhập và mã xác thực 2 lớp.</span>
        </div>
      </div>
    `;
    return;
  }

  // 2. Kịch bản Sàn thương mại điện tử (Shopee, Lazada, Voucher...)
  if (lower.includes("shopee") || lower.includes("voucher") || lower.includes("tiki") || lower.includes("lazada")) {
    xaiContentEl.innerHTML = `
      <div class="xai-item">
        <span>🎁</span>
        <div>
          <strong>Lừa đảo Khuyến mãi & Quà tặng ảo</strong>
          <span>Lợi dụng thương hiệu TMĐT lớn tung bẫy voucher ảo để kích thích lòng tham.</span>
        </div>
      </div>
      <div class="xai-item">
        <span>🌐</span>
        <div>
          <strong>Tên miền rác nguy hiểm (.xyz, .top, .click)</strong>
          <span>Đuôi tên miền giá rẻ thường xuyên bị các mạng lưới tội phạm sử dụng.</span>
        </div>
      </div>
    `;
    return;
  }

  // 3. Kịch bản Dịch vụ công / Thuế / VNeID
  if (lower.includes("gov") || lower.includes("vneid") || lower.includes("thue") || lower.includes("dichvucong")) {
    xaiContentEl.innerHTML = `
      <div class="xai-item">
        <span>🏛️</span>
        <div>
          <strong>Mạo danh Cổng Dịch vụ công / VNeID Quốc gia</strong>
          <span>Giả mạo cơ quan nhà nước nhằm dụ dỗ nạn nhân tải tệp ứng dụng độc hại (.apk).</span>
        </div>
      </div>
      <div class="xai-item">
        <span>⚠️</span>
        <div>
          <strong>Chiếm đoạt quyền trợ năng thiết bị</strong>
          <span>Ứng dụng độc hại cố gắng kiểm soát thiết bị và tự động trích xuất mã OTP ngân hàng.</span>
        </div>
      </div>
    `;
    return;
  }

  // 4. Mặc định: Ngân hàng / Tài chính
  xaiContentEl.innerHTML = `
    <div class="xai-item">
      <span>🚨</span>
      <div>
        <strong>Tên miền giả mạo thương hiệu (Typosquatting)</strong>
        <span>Cố tình sử dụng tên miền nhái dịch vụ ngân hàng với đuôi tên miền rủi ro cao (.top, .net).</span>
      </div>
    </div>
    <div class="xai-item">
      <span>🔒</span>
      <div>
        <strong>Biểu mẫu thu thập dữ liệu trái phép</strong>
        <span>Phát hiện cấu trúc form tự động đánh cắp mật khẩu ngân hàng và mã OTP.</span>
      </div>
    </div>
  `;
}
